<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Auth;
use Closure;
use Session;
class TokenAuth 
{

public function handle($request, Closure $next)
{
   // $token = $request->header('api_token');
   // print_r($user = \Illuminate\Support\Facades\Auth::guard('admin')->getUser());die;
    //if($token == Auth::guard('admin')->getUser()->api_token)
    {
     // return response()->json(['data'=>'APP_KEY not found'], 401);
    //}
    return $next($request);
}

}